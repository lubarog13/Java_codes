package laba_1;

public class Entity {
     private static int idCounter = 1;
 final long id;//приравнивается idCounter, после чего idCounter увеличивается на 1
protected String title;
protected double posX;
protected double posZ;
protected boolean agressive;
protected int maxHealth;
protected int health;
protected int attackDamage;

    public Entity( String title, double posX, double posZ, boolean agressive, int maxHealth, int health, int attackDamage) {
        this.id = idCounter;
        idCounter++;
        this.title = title;
        this.posX = posX;
        this.posZ = posZ;
        this.agressive = agressive;
        this.maxHealth = maxHealth;
        this.health = health;
        this.attackDamage = attackDamage;
    }
    public void update(){
        if (agressive){
            for(int i=0;i<GameServer.getInstance().getEntities().length;i++){
                if (GameServer.getInstance().getEntities()[i]!=null&&GameServer.getInstance().getEntities()[i]!=this){
                if(agressive &&Math.sqrt(Math.pow((GameServer.getInstance().getEntities()[i].getPosX()-posX),2)+
                        Math.pow(GameServer.getInstance().getEntities()[i].getPosZ()-posZ, 2))<20){
                    if (Math.sqrt(Math.pow((GameServer.getInstance().getEntities()[i].getPosX()-posX),2)+
                            Math.pow(GameServer.getInstance().getEntities()[i].getPosZ()-posZ, 2))<2){ attack(GameServer.getInstance().getEntities()[i]);
                    }
                    else {
                        if (GameServer.getInstance().getEntities()[i].getPosX() > posX) posX++;
                            else if (GameServer.getInstance().getEntities()[i].getPosX() < posX) posX--;
                        if (GameServer.getInstance().getEntities()[i].getPosZ() > posZ) posZ++;
                            else if (GameServer.getInstance().getEntities()[i].getPosZ() < posZ) posZ--;
                            break;
                        }
                }}
            }
        }
    }
    public void attack(Entity entity){
            entity.health-=attackDamage;
            if (entity.health<0){
                for(int i=0;i<GameServer.getInstance().getEntities().length;i++){
                    if(entity==GameServer.getInstance().getEntities()[i]){
                        System.out.println(title +" убил "+entity.title);
                        GameServer.getInstance().getEntities()[i]=null;
                    }
                }
            }
            if (entity instanceof EntityPlayer) {
                health -= entity.attackDamage + 0.5 * GameServer.getInstance().getDifficulty();
                if (health<0){
                    for(int i=0;i<GameServer.getInstance().getEntities().length;i++){
                        if(this==GameServer.getInstance().getEntities()[i]){
                            System.out.println(entity.title +" убил "+ title);
                            GameServer.getInstance().getEntities()[i]=null;
                        }
                    }
                }
            }
    }
    @Override
    public String toString() {
        return "Entity{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", posX=" + posX +
                ", posZ=" + posZ +
                ", agressive=" + agressive +
                ", maxHealth=" + maxHealth +
                ", health=" + health +
                ", attackDamage=" + attackDamage +
                '}';
    }

    public static int getIdCounter() {
        return idCounter;
    }

    public static void setIdCounter(int idCounter) {
        Entity.idCounter = idCounter;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getPosX() {
        return posX;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }

    public double getPosZ() {
        return posZ;
    }

    public void setPosZ(double posZ) {
        this.posZ = posZ;
    }

    public boolean isAgressive() {
        return agressive;
    }

    public void setAgressive(boolean agressive) {
        this.agressive = agressive;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAttackDamage() {
        return attackDamage;
    }

    public void setAttackDamage(int attackDamage) {
        this.attackDamage = attackDamage;
    }
}
