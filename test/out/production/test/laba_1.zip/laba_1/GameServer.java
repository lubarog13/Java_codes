package laba_1;

import java.util.Arrays;

public class GameServer {
    private String id;
    private int difficulty=1;
    private int updater=0;
    private static GameServer instance;
    private Entity[] entities;
    public static void main(String[] args){
        new GameServer();
    }
    public GameServer() {
        instance = this;
        entities = new Entity[7];
        entities[0]= new Entity("Dragon", 10, 15, true, 50, 50, 20);
        entities[1]=new Entity("Wolf", 30, 20, true, 30, 30, 10);
        entities[2] = new EntityPlayer("Me", 15, 10, true, 50, 45, 20, "hello");
        entities[3] = new Entity("Cow", 3, 8, false, 20, 20, 0);
        entities[4] = new Entity("Cow", 5, 10, false, 20, 20, 0);
        entities[5] = new Entity("Cow", 14, 11, false, 20, 20, 0);
        entities[6] = new EntityPlayer("Anouther", 15, 15, true, 50, 40, 25, "cool");
        for ( int i = 0; i < 30; i++ ) {
            updater++;
            instance.updateServer();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(instance);
        }
    }

    @Override
    public String toString() {
        return "GameServer{" +
                "id='" + id + '\'' +
                ", difficulty=" + difficulty +
                ", entities=" + Arrays.toString(entities) +
                '}';
    }

    public int getUpdater() {
        return updater;
    }

    public void setUpdater(int updater) {
        this.updater = updater;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public static GameServer getInstance() {
        return instance;
    }

    public static void setInstance(GameServer instance) {
        GameServer.instance = instance;
    }

    public Entity[] getEntities() {
        return entities;
    }

    public void setEntities(Entity[] entities) {
        this.entities = entities;
    }

    public void updateServer(){
            for ( int i = 0; i < entities.length; i++ ) {
                if (entities[i] != null) entities[i].update(); }
        }
}
